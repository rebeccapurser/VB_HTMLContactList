﻿Option Strict On
Imports System.IO
Public Class Form1
    Private Sub btnBuildWebsite_Click(sender As Object, e As EventArgs) Handles btnBuildWebsite.Click
        'declare stream variables and date variable
        Dim sw As StreamWriter
        Dim sr As StreamReader
        Dim s As String
        Dim ss() As String
        Dim d As Date

        'set today's date
        d = Today

        'create HTML file
        sw = File.CreateText("facultycontact.html")

        'write in top of website in HTML
        sw.WriteLine("<!DOCTYPE html>")
        sw.WriteLine("<html>")
        sw.WriteLine("<head>")
        sw.WriteLine("<title>Page Title</title>")
        sw.WriteLine("<style> body {background-color: lightcyan} </style>")
        sw.WriteLine("<img src=""uofsclogo.png"" alt=""UofSC Logo"" style=""float: right; width: 154.5px; height: 88.125;"">")
        sw.WriteLine("</head>")
        sw.WriteLine("<body>")
        sw.WriteLine("<h1>Faculty Contact Information - Rebecca Purser - " & d.ToString("D"))
        sw.WriteLine("<style> h1 {color:darkslategrey; font-family: rockwell;}</style>")
        sw.WriteLine("</h1>")
        sw.WriteLine("<p>This webpage provides the contact information for some of the faculty in the Integrated Information Technology department. This report was generated using both Visual Basic and HTML languages.  A file containing the contact information was read and then used to populate the table below.")
        sw.WriteLine("<style> p {font-family: franklin gothic book}</style>")
        sw.WriteLine("</p>")
        sw.WriteLine("<table>")
        sw.WriteLine("<style> table {border-collapse: collapse; width: 75%; margin: auto} table, td, th {border: 1px solid black;} </style>")
        sw.WriteLine("<tr>")
        sw.WriteLine("<th>Name</th> <th>Phone Number</th> <th>Email</th>")
        sw.WriteLine("</tr>")

        'read in the faculty contact file
        sr = File.OpenText(Application.StartupPath & "\facultyinformation.txt")

        'create each row of the table and populate it
        Do While sr.Peek > -1
            s = sr.ReadLine
            ss = s.Split(CChar(vbTab))
            sw.WriteLine("<tr>")
            If ss.Length = 3 Then
                sw.WriteLine("<td>" & ss(0) & "</td>")
                sw.WriteLine("<td>" & ss(1) & "</td>")
                sw.WriteLine("<td>" & ss(2) & "</td>")
            End If
            sw.WriteLine("</tr>")
        Loop

        'end table and close stream reader
        sw.WriteLine("</table>")
        sr.Close()

        'close HTML file
        sw.WriteLine("</body>")
        sw.WriteLine("</html>")

        'close stream writer
        sw.Close()
    End Sub

    Private Sub btnViewWebsite_Click(sender As Object, e As EventArgs) Handles btnViewWebsite.Click
        'view webpage within program
        WebBrowser1.Url = New Uri("file:///" & Application.StartupPath & "\facultycontact.html")

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        'close application
        Me.Close()
        Application.Exit()
    End Sub
End Class
