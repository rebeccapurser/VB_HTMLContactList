﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnBuildWebsite = New System.Windows.Forms.Button()
        Me.WebBrowser1 = New System.Windows.Forms.WebBrowser()
        Me.btnViewWebsite = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnBuildWebsite
        '
        Me.btnBuildWebsite.Location = New System.Drawing.Point(69, 497)
        Me.btnBuildWebsite.Name = "btnBuildWebsite"
        Me.btnBuildWebsite.Size = New System.Drawing.Size(88, 23)
        Me.btnBuildWebsite.TabIndex = 0
        Me.btnBuildWebsite.Text = "Build Website"
        Me.btnBuildWebsite.UseVisualStyleBackColor = True
        '
        'WebBrowser1
        '
        Me.WebBrowser1.Location = New System.Drawing.Point(23, 12)
        Me.WebBrowser1.MinimumSize = New System.Drawing.Size(20, 20)
        Me.WebBrowser1.Name = "WebBrowser1"
        Me.WebBrowser1.Size = New System.Drawing.Size(859, 480)
        Me.WebBrowser1.TabIndex = 1
        '
        'btnViewWebsite
        '
        Me.btnViewWebsite.Location = New System.Drawing.Point(172, 497)
        Me.btnViewWebsite.Name = "btnViewWebsite"
        Me.btnViewWebsite.Size = New System.Drawing.Size(80, 23)
        Me.btnViewWebsite.TabIndex = 2
        Me.btnViewWebsite.Text = "View Website"
        Me.btnViewWebsite.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(807, 497)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 3
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(912, 532)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnViewWebsite)
        Me.Controls.Add(Me.WebBrowser1)
        Me.Controls.Add(Me.btnBuildWebsite)
        Me.Name = "Form1"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnBuildWebsite As Button
    Friend WithEvents WebBrowser1 As WebBrowser
    Friend WithEvents btnViewWebsite As Button
    Friend WithEvents btnExit As Button
End Class
